with
    n_rent(n, c)
    AS
    (
        select COUNT(rentalNo) as n, clientNo as c
        from dbo.RentalAgreements
        where dateStart BETWEEN '1/1/2021' and '12/30/2021'
        GROUP BY clientNo
    )
select distinct clientName, clientTelNo, n as number_of_rentalagreement
FROM n_rent, dbo.Clients
    RIGHT OUTER JOIN dbo.RentalAgreements on Clients.clientNo=RentalAgreements.clientNo

order by n