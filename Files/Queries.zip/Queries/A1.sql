with
    distance(d, veh)
    as
    (
        select (mileageAfter-mileageBefore), VehiclevehLicenseNo
        from dbo.RentalAgreements
    )
select VehiclevehLicenseNo, clientNo, d as distance
from dbo.RentalAgreements, distance
where d>6000 and veh = VehiclevehLicenseNo
order by veh