with avg_s(avg_salary) as 
(SELECT AVG(salary)
from dbo.Employees
where Title='Mechanic'),
worker(outlet,employee)as 
(select outletNo,employeeNo
from dbo.Employees,avg_s
where salary>avg_salary)

select outlet, COUNT(employee) as num_of_mechanic
from worker
GROUP BY outlet