with
    n_fault(n, outlet)
    as
    (
        select count(vehLicenseNo) as n, outletNo as outlet
        from dbo.FaultReports
            JOIN dbo.Employees on FaultReports.EmployeeNo=Employees.EmployeeNo
        GROUP BY outletNo
    )
select outlet, outletCity, n as num_of_fault
FROM n_fault
    LEFT OUTER JOIN dbo.Outlets on outlet=Outlets.outletNo
ORDER BY n DESC