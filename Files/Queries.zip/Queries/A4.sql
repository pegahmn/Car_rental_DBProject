
with
    tab(vehLicenseNo, model, rentalNo)
    AS
    (
        select vehLicenseNo, vehicleModel, rentalNo
        FROM dbo.Vehicles
            LEFT OUTER JOIN dbo.RentalAgreements on Vehicles.vehLicenseNo=RentalAgreements.VehiclevehLicenseNo
        where hireRate BETWEEN 100 and 350

    ),
    num(num_of_rent, vehLicenseNo)
    as
    (
        select count(rentalNo), vehLicenseNo
        from tab
        GROUP by vehLicenseNo
    )

select distinct tab.vehLicenseNo, model, num_of_rent
from tab, num
where rentalNo is not null and num.vehLicenseNo=tab.vehLicenseNo
