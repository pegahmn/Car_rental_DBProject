
select vehLicenseNo, timeChecked, EmployeeNo
from dbo.FaultReports
where dateChecked between '2018-01-01' and '2018-12-30'
ORDER by timeChecked