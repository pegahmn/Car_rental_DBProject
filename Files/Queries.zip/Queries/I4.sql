select vehicleModel, dateStart, dateReturn
from dbo.Vehicles
    left OUTER join dbo.RentalAgreements on Vehicles.vehLicenseNo=RentalAgreements.VehiclevehLicenseNo
where hireRate BETWEEN 350 and 800 and dateStart is NOT NULL
