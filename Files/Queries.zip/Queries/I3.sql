WITH
    d_s(cn_s, m_s, y_s,rentno_s)
    AS
    (
        select clientNo as cn_s, MONTH(dateStart) as m_s, YEAR(dateStart) as y_s,rentalNo
        from dbo.RentalAgreements
    ),
    d_r(cn_r, m_r, y_r,rentno_r)
    as
    (
        select clientNo as cn_r, MONTH(dateReturn) as m_r, YEAR(dateReturn) as y_r,rentalNo
        from dbo.RentalAgreements
    ),
    pr(client_no, rent_period)
    as
    (
        SELECT cn_r , CASE
        WHEN y_r=y_s THEN (m_r-m_s)
        WHEN y_r>y_s THEN ((12-m_s)+m_r) END as rent_period
        from d_r, d_s
        where d_r.cn_r=d_s.cn_s and rentno_r=rentno_s
    )
SELECT *
from pr
where rent_period>4

