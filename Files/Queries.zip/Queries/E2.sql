with
    n_v(outletNo, number_0f_vehicles)
    as
    (
        select outletNo, count(vehLicenseNo)
        from dbo.Vehicles
        GROUP BY outletNo
    )
SELECT *
from n_v