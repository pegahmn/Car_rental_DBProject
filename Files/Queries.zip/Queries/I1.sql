with
    num(outletCity, nu)
    as
    (
        select outletCity, COUNT(outletCity) as nu
        from dbo.Outlets
        GROUP BY outletCity
    ),

    cit(city)
    AS
    (
        select outletCity
        from num
        where nu>1
    ),
    outlet_n(outletNo, outlet_city, veh)
    AS
    (
        select Outlets.outletNo, outletCity, vehLicenseNo
        from cit
            left outer join dbo.Outlets on cit.city=Outlets.outletCity
            left outer join dbo.Vehicles on Outlets.outletNo=Vehicles.outletNo
    ),
    num_of_agreement(outlet_city, outletNo, number_of_Agreement)
    as
    (
        SELECT outlet_city, outletNo, COUNT(rentalNo)
        from outlet_n, dbo.RentalAgreements
        WHERE veh=VehiclevehLicenseNo
        GROUP by outletNo,outlet_city
    )

SELECT *
from num_of_agreement


